<?php
return array(
    'app.installer'=>array(
        'version'=>'>=1.7.20',
        'strict'=>true,
    ),
);
//EOF