<?php

return array(
	'front_controller' => array('blogFrontController')
);
