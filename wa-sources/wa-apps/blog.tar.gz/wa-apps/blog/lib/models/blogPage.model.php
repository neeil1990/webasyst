<?php

class blogPageModel extends waPageModel
{
    protected $app_id = 'blog';
    protected $table = 'blog_page';
}