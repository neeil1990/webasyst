<?php

return array(
    'code' => 'UAH',
    'sign' => 'грн.',
	'iso4217' => '980',
    'title' => 'Ukrainian hryvnia',
    'name' => array(
        array('hryvnia', 'hryvnias'),
        'hrn',
    ),
    'frac_name' => array(
        array('kopiyka', 'kopiykas'),
    )
);