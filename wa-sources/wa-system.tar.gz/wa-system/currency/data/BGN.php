<?php

return array(
    'code' => 'BGN',
    'sign' => 'лв',
	'iso4217' => '975',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Bulgarian lev',
    'name' => array(
        'lev',
    ),
    'frac_name' => array(
        array('stotinka', 'stotinki'),
    )
);